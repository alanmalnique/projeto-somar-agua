# Projeto Somar Água na Silhueta

## Requisitos necessarios

`
PHP >= 7.2.5
`
`
Composer 2.3.5
`

## Como Iniciar o projeto:

`
composer install
`

### Como rodar os Testes Unitarios
# Windows
`
.\vendor\bin\phpunit
`

# Linux
`
./vendor/bin/phpunit